import React from 'react';
import ReactDOM from 'react-dom/client';
import Reminder from './Reminder';
import './Reminder.css';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Reminder />);

