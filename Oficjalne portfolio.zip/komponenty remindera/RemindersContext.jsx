import {createContext} from 'react'

const remindersContext = createContext([]);

export default remindersContext;
